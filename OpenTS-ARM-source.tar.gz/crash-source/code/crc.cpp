/*******************************************************************************
 *                                O P E N  T S
 *******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2025 Electronic Arts Inc.
 * Copyright 2026 OpenTS contributors
 *
 * Contains material derived from Electronic Arts source code.
 * Modified by OpenTS contributors, 2026.
 * EA's GPLv3 Section 7 additional terms and supplemental warranty
 * disclaimers apply; see LICENSE.md.
 ******************************************************************************/

/***********************************************************************************************
 ***              C O N F I D E N T I A L  ---  W E S T W O O D  S T U D I O S               ***
 ***********************************************************************************************
 *                                                                                             *
 *                 Project Name : Command & Conquer                                            *
 *                                                                                             *
 *                     $Archive:: /Commando/Code/wwlib/CRC.CPP                                $*
 *                                                                                             *
 *                      $Author:: Eric_c                                                      $*
 *                                                                                             *
 *                     $Modtime:: 10/22/98 2:46p                                              $*
 *                                                                                             *
 *                    $Revision:: 2                                                           $*
 *                                                                                             *
 *---------------------------------------------------------------------------------------------*
 * Functions:                                                                                  *
 *   CRCEngine::operator() -- Submits one byte of data to the CRC engine.                      *
 *   CRCEngine::operator() -- Submits an arbitrary data block to the CRC engine.               *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

#include "always.h"

#include "crc.h"

#include <cstring>

/***********************************************************************************************
 * CRCEngine::operator() -- Submits one byte of data to the CRC engine.                        *
 *                                                                                             *
 *    This routine will take the specified byte of data and submit it to the CRC engine        *
 *    for processing. This routine is designed to be as fast as possible since the typical     *
 *    use of this routine is to feed one of presumably many byte sized chunks of data to the   *
 *    CRC engine.                                                                              *
 *                                                                                             *
 * INPUT:   datum -- One byte of data to submit to the CRC engine.                             *
 *                                                                                             *
 * OUTPUT:  none                                                                               *
 *                                                                                             *
 * WARNINGS:   If possible, use the buffer/size operator to submit data rather than repeated   *
 *             calls to this routine.                                                          *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   03/02/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
void CRCEngine::operator() (char datum)
{
	Submit(datum);
}


/// <summary>
/// Submits one boolean datum to the CRC engine.
/// This is the boolean flavor of the byte sized submission operator.
/// </summary>
void CRCEngine::operator() (bool datum)
{
	Submit(datum != false);
}


/// <summary>
/// Submits one word sized datum to the CRC engine.
/// </summary>
void CRCEngine::operator() (short datum)
{
	/// Union used to ensure the datum type is passed into the engine as a composite.
	union {
		short Composite;
		short Datum;
	} _datum;

	_datum.Datum = datum;

	(*this)(&_datum.Composite, sizeof(_datum.Composite));
}


/// <summary>
/// Submits one long word sized datum to the CRC engine.
/// </summary>
void CRCEngine::operator() (int datum)
{
	/// Union used to ensure the datum type is passed into the engine as a composite.
	union {
		int Composite;
		int Datum;
	} _datum;

	_datum.Datum = datum;

	(*this)(&_datum.Composite, sizeof(_datum.Composite));
}


/// <summary>
/// Submits one floating point datum to the CRC engine.
/// The value is submitted as its raw bit pattern rather than as a number, so two values
/// that compare equal but differ in representation will not agree on the CRC.
/// </summary>
void CRCEngine::operator() (float datum)
{
	/// Union used to ensure the datum type is passed into the engine as a composite.
	union {
		int Composite;
		float Datum;
	} _datum;

	_datum.Datum = datum;

	(*this)(&_datum.Composite, sizeof(_datum.Composite));
}


/// <summary>
/// Submits one double precision datum to the CRC engine.
/// The value is submitted as its raw bit pattern rather than as a number.
/// </summary>
void CRCEngine::operator() (double datum)
{
	double _datum = datum;

	(*this)(&_datum, sizeof(_datum));
}


/// <summary>
/// Submits a null terminated string to the CRC engine.
/// The terminator itself is not submitted, so a string contributes the same value here
/// as its characters would if submitted one at a time. A NULL pointer is ignored.
/// </summary>
/// <param name="buffer">Pointer to the string to submit. It will not be modified.</param>
void CRCEngine::operator() (const char * buffer)
{
	if (buffer != NULL) {
		(*this)(buffer, strlen(buffer));
	}
}


/***********************************************************************************************
 * CRCEngine::operator() -- Submits an arbitrary data block to the CRC engine.                 *
 *                                                                                             *
 *    This routine will submit the specified block to the CRC engine. The block can be of      *
 *    arbitrary length.                                                                        *
 *                                                                                             *
 * INPUT:   buffer   -- Pointer to the buffer that contains the data. The buffer will not      *
 *                      be modified.                                                           *
 *                                                                                             *
 *          length   -- The length of the buffer (in bytes).                                   *
 *                                                                                             *
 * OUTPUT:  Returns with the current CRC value accumulated so far.                             *
 *                                                                                             *
 * WARNINGS:   none                                                                            *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   03/02/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
int CRCEngine::operator() (void const * buffer, int length)
{
	if (buffer != NULL && length > 0)  {
		char const * dataptr = (char const *)buffer;
		int bytes_left = length;

		/*
		**	If there are any leader bytes (needed to fill the staging buffer)
		**	then process those by first using them to fill up the staging
		**	buffer. The bulk of the data block will be processed by the high
		**	speed longword processing loop.
		*/
		while (bytes_left > 0 && Buffer_Needs_Data() && Index < sizeof(int)) {
			operator()(*dataptr);
			dataptr++;
			bytes_left--;
		}

		/*
		**	Perform the fast 'bulk' processing by reading long word sized
		**	data blocks.
		*/
		int const * longptr = (int const *)dataptr;
		int longcount = bytes_left / sizeof(int);		// Whole 'long' elements remaining.
		while (longcount--) {
			//CRC = _lrotl(CRC, 1) + *longptr++;
			CRC = CRC::Memory((unsigned char *)longptr, sizeof(int), CRC);
			bytes_left -= sizeof(int);
			longptr++;
		}

		/*
		**	If there are remainder bytes, then process these by adding them
		**	to the staging buffer.
		*/
		dataptr = (char const *)longptr;
		while (bytes_left > 0) {
			operator()(*dataptr);
			dataptr++;
			bytes_left--;
		}
	}

	/*
	**	Return the current CRC value.
	*/
	return(Value());
}
//    CRC for poly 0x04C11DB7
unsigned int  CRC::_Table[ 256 ] =
{
	0x00000000L, 0x77073096L, 0xEE0E612CL, 0x990951BAL,
	0x076DC419L, 0x706AF48FL, 0xE963A535L, 0x9E6495A3L,
	0x0EDB8832L, 0x79DCB8A4L, 0xE0D5E91EL, 0x97D2D988L,
	0x09B64C2BL, 0x7EB17CBDL, 0xE7B82D07L, 0x90BF1D91L,
	0x1DB71064L, 0x6AB020F2L, 0xF3B97148L, 0x84BE41DEL,
	0x1ADAD47DL, 0x6DDDE4EBL, 0xF4D4B551L, 0x83D385C7L,
	0x136C9856L, 0x646BA8C0L, 0xFD62F97AL, 0x8A65C9ECL,
	0x14015C4FL, 0x63066CD9L, 0xFA0F3D63L, 0x8D080DF5L,
	0x3B6E20C8L, 0x4C69105EL, 0xD56041E4L, 0xA2677172L,
	0x3C03E4D1L, 0x4B04D447L, 0xD20D85FDL, 0xA50AB56BL,
	0x35B5A8FAL, 0x42B2986CL, 0xDBBBC9D6L, 0xACBCF940L,
	0x32D86CE3L, 0x45DF5C75L, 0xDCD60DCFL, 0xABD13D59L,
	0x26D930ACL, 0x51DE003AL, 0xC8D75180L, 0xBFD06116L,
	0x21B4F4B5L, 0x56B3C423L, 0xCFBA9599L, 0xB8BDA50FL,
	0x2802B89EL, 0x5F058808L, 0xC60CD9B2L, 0xB10BE924L,
	0x2F6F7C87L, 0x58684C11L, 0xC1611DABL, 0xB6662D3DL,
	0x76DC4190L, 0x01DB7106L, 0x98D220BCL, 0xEFD5102AL,
	0x71B18589L, 0x06B6B51FL, 0x9FBFE4A5L, 0xE8B8D433L,
	0x7807C9A2L, 0x0F00F934L, 0x9609A88EL, 0xE10E9818L,
	0x7F6A0DBBL, 0x086D3D2DL, 0x91646C97L, 0xE6635C01L,
	0x6B6B51F4L, 0x1C6C6162L, 0x856530D8L, 0xF262004EL,
	0x6C0695EDL, 0x1B01A57BL, 0x8208F4C1L, 0xF50FC457L,
	0x65B0D9C6L, 0x12B7E950L, 0x8BBEB8EAL, 0xFCB9887CL,
	0x62DD1DDFL, 0x15DA2D49L, 0x8CD37CF3L, 0xFBD44C65L,
	0x4DB26158L, 0x3AB551CEL, 0xA3BC0074L, 0xD4BB30E2L,
	0x4ADFA541L, 0x3DD895D7L, 0xA4D1C46DL, 0xD3D6F4FBL,
	0x4369E96AL, 0x346ED9FCL, 0xAD678846L, 0xDA60B8D0L,
	0x44042D73L, 0x33031DE5L, 0xAA0A4C5FL, 0xDD0D7CC9L,
	0x5005713CL, 0x270241AAL, 0xBE0B1010L, 0xC90C2086L,
	0x5768B525L, 0x206F85B3L, 0xB966D409L, 0xCE61E49FL,
	0x5EDEF90EL, 0x29D9C998L, 0xB0D09822L, 0xC7D7A8B4L,
	0x59B33D17L, 0x2EB40D81L, 0xB7BD5C3BL, 0xC0BA6CADL,
	0xEDB88320L, 0x9ABFB3B6L, 0x03B6E20CL, 0x74B1D29AL,
	0xEAD54739L, 0x9DD277AFL, 0x04DB2615L, 0x73DC1683L,
	0xE3630B12L, 0x94643B84L, 0x0D6D6A3EL, 0x7A6A5AA8L,
	0xE40ECF0BL, 0x9309FF9DL, 0x0A00AE27L, 0x7D079EB1L,
	0xF00F9344L, 0x8708A3D2L, 0x1E01F268L, 0x6906C2FEL,
	0xF762575DL, 0x806567CBL, 0x196C3671L, 0x6E6B06E7L,
	0xFED41B76L, 0x89D32BE0L, 0x10DA7A5AL, 0x67DD4ACCL,
	0xF9B9DF6FL, 0x8EBEEFF9L, 0x17B7BE43L, 0x60B08ED5L,
	0xD6D6A3E8L, 0xA1D1937EL, 0x38D8C2C4L, 0x4FDFF252L,
	0xD1BB67F1L, 0xA6BC5767L, 0x3FB506DDL, 0x48B2364BL,
	0xD80D2BDAL, 0xAF0A1B4CL, 0x36034AF6L, 0x41047A60L,
	0xDF60EFC3L, 0xA867DF55L, 0x316E8EEFL, 0x4669BE79L,
	0xCB61B38CL, 0xBC66831AL, 0x256FD2A0L, 0x5268E236L,
	0xCC0C7795L, 0xBB0B4703L, 0x220216B9L, 0x5505262FL,
	0xC5BA3BBEL, 0xB2BD0B28L, 0x2BB45A92L, 0x5CB36A04L,
	0xC2D7FFA7L, 0xB5D0CF31L, 0x2CD99E8BL, 0x5BDEAE1DL,
	0x9B64C2B0L, 0xEC63F226L, 0x756AA39CL, 0x026D930AL,
	0x9C0906A9L, 0xEB0E363FL, 0x72076785L, 0x05005713L,
	0x95BF4A82L, 0xE2B87A14L, 0x7BB12BAEL, 0x0CB61B38L,
	0x92D28E9BL, 0xE5D5BE0DL, 0x7CDCEFB7L, 0x0BDBDF21L,
	0x86D3D2D4L, 0xF1D4E242L, 0x68DDB3F8L, 0x1FDA836EL,
	0x81BE16CDL, 0xF6B9265BL, 0x6FB077E1L, 0x18B74777L,
	0x88085AE6L, 0xFF0F6A70L, 0x66063BCAL, 0x11010B5CL,
	0x8F659EFFL, 0xF862AE69L, 0x616BFFD3L, 0x166CCF45L,
	0xA00AE278L, 0xD70DD2EEL, 0x4E048354L, 0x3903B3C2L,
	0xA7672661L, 0xD06016F7L, 0x4969474DL, 0x3E6E77DBL,
	0xAED16A4AL, 0xD9D65ADCL, 0x40DF0B66L, 0x37D83BF0L,
	0xA9BCAE53L, 0xDEBB9EC5L, 0x47B2CF7FL, 0x30B5FFE9L,
	0xBDBDF21CL, 0xCABAC28AL, 0x53B39330L, 0x24B4A3A6L,
	0xBAD03605L, 0xCDD70693L, 0x54DE5729L, 0x23D967BFL,
	0xB3667A2EL, 0xC4614AB8L, 0x5D681B02L, 0x2A6F2B94L,
	0xB40BBE37L, 0xC30C8EA1L, 0x5A05DF1BL, 0x2D02EF8DL
};


/// <summary>
/// Calculates the CRC of a block of memory.
/// This is the low level routine that the CRC engine and the string flavor both build
/// upon. The block will not be modified.
/// </summary>
/// <param name="length">The length of the block, in bytes.</param>
/// <param name="crc">The CRC value to accumulate onto. Pass the result of a previous
/// call in order to chain several blocks into one value.</param>
/// <returns>Returns with the CRC of the block.</returns>
unsigned int	CRC::Memory( unsigned char const *data, unsigned int length, unsigned int crc )
{
	crc ^= 0xFFFFFFFF;									// invert previous CRC
	while ( length-- ) {
		crc = CRC32( *data++, crc );					// calc crc for each byte
	}
	return(crc ^ 0xFFFFFFFF); 						// invert new CRC and return it
}


/// <summary>
/// Calculates the CRC of a null terminated string.
/// Use this routine where a name or a key must be reduced to a single integer that can
/// be compared or hashed cheaply. The terminator itself does not contribute.
/// </summary>
/// <param name="crc">The CRC value to accumulate onto. Pass the result of a previous
/// call in order to chain several strings into one value.</param>
/// <returns>Returns with the CRC of the string.</returns>
unsigned int	CRC::String( const char *string, unsigned int crc)
{
	crc ^= 0xFFFFFFFF;									// invert previous CRC
	while ( *string )	{
		crc = CRC32( *string++, crc );				// calc crc for each byte
	}
	return(crc ^ 0xFFFFFFFF); 						// invert new CRC and return it
}
