/*******************************************************************************
 *                                O P E N  T S
 *******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2025 Electronic Arts Inc.
 * Copyright 2026 OpenTS contributors
 *
 * Contains material derived from Electronic Arts source code.
 * Modified by OpenTS contributors, 2026.
 * EA's GPLv3 Section 7 additional terms and supplemental warranty
 * disclaimers apply; see LICENSE.md.
 ******************************************************************************/

/* $Header: /CounterStrike/GADGET.H 1     3/03/97 10:24a Joe_bostic $ */
/***********************************************************************************************
 ***              C O N F I D E N T I A L  ---  W E S T W O O D  S T U D I O S               ***
 ***********************************************************************************************
 *                                                                                             *
 *                 Project Name : Command & Conquer                                            *
 *                                                                                             *
 *                    File Name : GADGET.H                                                     *
 *                                                                                             *
 *                   Programmer : Maria del Mar McCready Legg                                  *
 *                                                                                             *
 *                   Start Date : January 3, 1995                                              *
 *                                                                                             *
 *                  Last Update : January 3, 1995   [MML]                                      *
 *                                                                                             *
 *                                                                                             *
 *        LinkClass [This is the linked list manager class. It keeps a record                  *
 *            |      of the next and previous gadget in the list. It is possible               *
 *            |      delete a gadget out of the middle of the list with this                   *
 *            |      class.]                                                                   *
 *            |                                                                                *
 *       GadgetClass [The is the basic gadget class. It handles processing of                  *
 *            |       input events and dispatching the appropriate functions.                  *
 *            |       All gadgets must be derived from this class.]                            *
 *            +----+                                                                           *
 *            |    |                                                                           *
 *            |  ListClass [This list class functions like a list box does in Windows. It      *
 *            |             keeps track of a list of text strings. This list can be            *
 *            |             scrolled and an item selected. If the list becomes larger than     *
 *            |             can be completely displayed, it will automatically create a        *
 *            |             slider (at the right edge) to manage the scrolling.]               *
 *            |                                                                                *
 *      ControlClass [This class adds the concept of giving an ID number to the                *
 *            |       gadget. This ID can then be returned from the Input()                    *
 *            |       function as if it were a pseudo-keystroke. Additionally,                 *
 *            |       the ability to inform another button that this button has                *
 *            |       been actioned is allowed. This ability allows one button                 *
 *            |       to watch what happens to another button. Example: a list                 *
 *            |       box gadget can tell when an attached slider has been                     *
 *            |       touched.]                                                                *
 *    +-------+----+                                                                           *
 *    |       |    |                                                                           *
 *    |       |  GaugeClass [This class looks similar to Windows slider, but has               *
 *    |       |    |         a different controlling logic. There is no thumb and              *
 *    |       |    |         it serves as a simple variable control setting. This              *
 *    |       |    |         is analogous to a volume slider.]                                 *
 *    |       |    |                                                                           *
 *    |       | SliderClass [The slider class is similar to the typical Windows slider. It     *
 *    |       |              has a current setting, a thumb, and a controllable scale. This    *
 *    |       |              is the object created to handle a scrolling list box.]            *
 *    |       |                                                                                *
 *    |   EditClass                                                                            *
 *    |                                                                                        *
 *    |                                                                                        *
 * ToggleClass [The toggle class is used for buttons that have an image and behave just        *
 *    |         like the buttons in Windows do. That is, they have a separate visual for       *
 *    |         when they are pressed and raised. They are officially triggered (return        *
 *    |         their ID number) when the mouse button is released while over the button.      *
 *    |         This class doesn't perform any rendering itself. It merely provides the        *
 *    |         logic so that the derived classes will function correctly.]                    *
 *  +-+----+                                                                                   *
 *  |      |                                                                                   *
 *  |   TextButtonClass [The text button functions like a normal Windows style button, but     *
 *  |                    the imagery is based on text that is displayed on the button. A       *
 *  |                    typical example would be the "OK" or "Cancel" buttons.]               *
 *  |                                                                                          *
 * ShapeButtonClass [The shape buttons is similar to the TextButton but instead of text        *
 *                   being used to give the button its imagery, an actual shape is used        *
 *                   instead. This allows graphic buttons. These are similar to the up/down    *
 *                   arrows seen in a Windows slider.]                                         *
 *                                                                                             *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

#pragma once

#include "keyboard.h"
#include "link.h"

#include "scheme.hh"


class ControlClass;

#ifndef DEFAULT_GADGET_SCHEME
#define DEFAULT_GADGET_SCHEME "Grey"
#endif

class GadgetClass : public LinkClass
{
		typedef LinkClass BASECLASS;

	public:
		enum FlagEnum {
			LEFTPRESS    = 0x0001,	// Left mouse button press.
			LEFTHELD     = 0x0002,	// Left mouse button is being held down.
			LEFTRELEASE  = 0x0004,	// Left mouse button released.
			LEFTUP       = 0x0008,	// Left mouse button is being held up.
			RIGHTPRESS   = 0x0010,	// Right mouse button press.
			RIGHTHELD    = 0x0020,	// Right mouse button is being held down.
			RIGHTRELEASE = 0x0040,	// Right mouse button released.
			RIGHTUP      = 0x0080,	// Right mouse button is being held up.
			KEYBOARD     = 0x0100	// Keyboard input processing (maybe).
		};

		GadgetClass(int x, int y, int w, int h, unsigned flags, bool sticky=false);
		GadgetClass(void) {};
		GadgetClass(GadgetClass const & gadget);
		virtual ~GadgetClass(void) override;

		/*
		**	Gadget list management functions.
		*/
		virtual KeyNumType Input(void);
		virtual void Draw_All(bool forced=true);
		virtual void Delete_List(void);
		virtual ControlClass * Extract_Gadget(unsigned id);
		virtual void Flag_List_To_Redraw(void) {LastList = 0;};
		virtual LinkClass * Remove(void) override;
		virtual LinkClass * Get_Next(void) const override;
		virtual LinkClass * Get_Prev(void) const override;

		/*
		**	Manages individual gadget states and actions.
		*/
		virtual void Disable(void);
		virtual void Enable(void);
		virtual unsigned Get_ID(void) const {return(0);};
		virtual void Flag_To_Redraw(void);
		virtual void Peer_To_Peer(unsigned , KeyNumType & , ControlClass & ) {};
		virtual void Set_Focus(void);
		virtual void Clear_Focus(void);
		virtual bool Has_Focus(void);
		virtual int  Is_List_To_Redraw(void);
		virtual bool Is_To_Redraw(void) {return(IsToRepaint);}
		virtual void Set_Position(int x, int y);
		virtual void Set_Size(int w, int h);

		void Set_Flags(unsigned flags) { Flags = flags; }

		/*
		**	General render function.
		*/
		virtual int Draw_Me(int forced=false);

		/*
		**	Sets the current color scheme
		*/
		/// UNSAFE
		static void Set_Color_Scheme(const char *scheme) { CurrentColorScheme = scheme; }

		static int Get_Color_Scheme(void);

		/*
		**	This is the coordinates and dimensions of the gadget region. These are in
		**	absolute screen pixel coordinates.
		*/
		int X;
		int Y;
		int Width;
		int Height;

	protected:

		/*
		**	Processes the event flags so that if this gadget needs to "stick" or
		**	"unstick", it will be properly flagged. Call this function if you are
		**	going to clear the button press flags before calling the base class
		**	Action() function. Otherwise, calling this function manually, is
		**	unnecessary since the base class Action() function already does so.
		*/
		virtual void Sticky_Process(unsigned flags);

		/*
		**	This is the action function that will be called whenever the flags and mouse
		**	input indicates. This is the main method by which this button performs a useful
		**	function.
		*/
		virtual int Action(unsigned flags, KeyNumType & key);

		/*
		**	This is a record of the last list passed to the Input() function. If a list
		**	different than the last recorded one is detected, then the draw function is
		**	called for every gadget in the list. This causes all buttons to be redrawn the
		**	fire time Input() is called without forced a manual call to Draw_All().
		*/
		static GadgetClass * LastList;

		/*
		**	This points to the gadget that has the keyboard focus. All keyboard only
		**	events are fed to this gadget to the exclusion of all others.
		*/
		static GadgetClass * Focused;

		/*
		**	This button should call the Draw_Me function because some graphic element needs
		**	to be redrawn. This flag is set by default if the Action function is called.
		*/
		bool IsToRepaint;

	public:		// HACK HACK HACK.. this is here because the sidebar buttons are static.
		/*
		**	A sticky button is one that is processed to the exclusion of all other buttons
		**	IF the mouse was pressed down while over this button and the mouse continues
		**	to remain pressed. This is the standard behavior for all normal Windows style
		**	buttons.
		*/
		bool IsSticky;

	protected:
		/*
		**	If there is a sticky button being processed, then this will point to it. A sticky
		**	button is one that will ONLY be processed while the mouse button is being
		**	held down.
		*/
		static GadgetClass * StuckOn;

		/*
		**	If the button is disabled, then it won't be processed by the input function. It will
		**	have its Draw_Me function called as necessary. In order to not display the button
		**	at all, the appropriate draw function should perform no action -- just return. Or,
		**	just remove the button from the list.
		*/
		bool IsDisabled;

		/*
		**	These are the action flags that are used to determine when the action function
		**	should be called. Example: If this gadget only wants the action button called when
		**	the left mouse button is pressed over the its region, then the flag will be set
		**	to LEFTPRESS.
		*/
		unsigned Flags;

	public:
		/*
		**	This is the current color scheme; it must be initialized by the app.
		*/
		static const char *CurrentColorScheme;

	private:
		virtual int Clicked_On(KeyNumType & key, unsigned flags, int x, int y);
};
