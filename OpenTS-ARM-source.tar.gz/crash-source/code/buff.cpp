/*******************************************************************************
 *                                O P E N  T S
 *******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2025 Electronic Arts Inc.
 * Copyright 2026 OpenTS contributors
 *
 * Contains material derived from Electronic Arts source code.
 * Modified by OpenTS contributors, 2026.
 * EA's GPLv3 Section 7 additional terms and supplemental warranty
 * disclaimers apply; see LICENSE.md.
 ******************************************************************************/

/***********************************************************************************************
 ***              C O N F I D E N T I A L  ---  W E S T W O O D  S T U D I O S               ***
 ***********************************************************************************************
 *                                                                                             *
 *                 Project Name : Command & Conquer                                            *
 *                                                                                             *
 *                     $Archive:: /G/wwlib/BUFF.CPP                                           $*
 *                                                                                             *
 *                      $Author:: Eric_c                                                      $*
 *                                                                                             *
 *                     $Modtime:: 4/15/99 10:14a                                              $*
 *                                                                                             *
 *                    $Revision:: 2                                                           $*
 *                                                                                             *
 *---------------------------------------------------------------------------------------------*
 * Functions:                                                                                  *
 *   Buffer::Buffer -- Constructor for buffer object.                                          *
 *   Buffer::Buffer -- Copy constructor for buffer object.                                     *
 *   Buffer::Buffer -- Self-allocating constructor for buffer object.                          *
 *   Buffer::Reset -- Clears the buffer object to null state.                                  *
 *   Buffer::operator = -- Assignment operator for the buffer object.                          *
 *   Buffer::~Buffer -- Destructor for buffer object.                                          *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

#include "always.h"

#include "buff.h"

/***********************************************************************************************
 * Buffer::Buffer -- Constructor for buffer object.                                            *
 *                                                                                             *
 *    This is the normal constructor for a buffer object. The buffer pointer and size are      *
 *    specified as parameters.                                                                 *
 *                                                                                             *
 * INPUT:   buffer   -- Pointer to the buffer.                                                 *
 *                                                                                             *
 *          size     -- The size of the buffer.                                                *
 *                                                                                             *
 * OUTPUT:  none                                                                               *
 *                                                                                             *
 * WARNINGS:   It is possible to construct a Buffer object that has a pointer but a size       *
 *             value of zero. The Buffer object can still be used for its pointer, but it      *
 *             any function that requires a size will fail.                                    *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   07/29/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
Buffer::Buffer(void * buffer, int size) :
	BufferPtr(buffer),
	Size(size),
	IsAllocated(false)
{
	if (buffer == NULL && size > 0) {
		BufferPtr = new char[size];
		IsAllocated = true;
	}
}


// Alternate constructor for char * pointer.

/// <summary>
/// Constructor for a buffer object described by a character pointer.
/// This is a convenience form of the normal constructor for the common case of a raw
/// character buffer. As with the normal constructor, a NULL pointer paired with a non-zero
/// size causes the buffer object to allocate the memory itself and free it when it dies.
/// </summary>
/// <param name="buffer">Pointer to the buffer, or NULL to have one allocated.</param>
Buffer::Buffer(char * buffer, int size) :
	BufferPtr(buffer),
	Size(size),
	IsAllocated(false)
{
	if (buffer == NULL && size > 0) {
		BufferPtr = new char[size];
		IsAllocated = true;
	}
}


// Alternate constructor for void const * pointer.

/// <summary>
/// Constructor for a buffer object described by a constant pointer.
/// This is a convenience form of the normal constructor for callers that hold their data
/// as constant. As with the normal constructor, a NULL pointer paired with a non-zero size
/// causes the buffer object to allocate the memory itself.
/// </summary>
/// <param name="buffer">Pointer to the buffer, or NULL to have one allocated.</param>
/// <remarks>The constant qualifier is discarded when the pointer is stored, so nothing
/// stops the buffer from being written through this object.</remarks>
Buffer::Buffer(void const * buffer, int size) :
	BufferPtr((void*)buffer),
	Size(size),
	IsAllocated(false)
{
	if (buffer == NULL && size > 0) {
		BufferPtr = new char[size];
		IsAllocated = true;
	}
}


/***********************************************************************************************
 * Buffer::Buffer -- Self-allocating constructor for buffer object.                            *
 *                                                                                             *
 *    This construtor for a buffer object will automatically allocate the bytes necessary      *
 *    to fulfill the size requested. This object is also responsible for deleting the buffer   *
 *    it allocated.                                                                            *
 *                                                                                             *
 * INPUT:   size  -- The size of the buffer to allocated.                                      *
 *                                                                                             *
 * OUTPUT:  none                                                                               *
 *                                                                                             *
 * WARNINGS:   There is no way to tell if the allocation failed. To verify, call Get_Buffer    *
 *             and compare with NULL.                                                          *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   07/29/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
Buffer::Buffer(int size) :
	BufferPtr(NULL),
	Size(size),
	IsAllocated(false)
{
	if (size > 0) {
		BufferPtr = new char[size];
		IsAllocated = true;
	}
}


/***********************************************************************************************
 * Buffer::Buffer -- Copy constructor for buffer object.                                       *
 *                                                                                             *
 *    This will make a duplicate of the specified buffer object. The ownership of the pointer  *
 *    remains with the original object. This prevents multiple deletion of the same pointer.   *
 *                                                                                             *
 * INPUT:   buffer   -- Reference to the buffer object to be dupilcated.                       *
 *                                                                                             *
 * OUTPUT:  none                                                                               *
 *                                                                                             *
 * WARNINGS:   none                                                                            *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   08/02/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
Buffer::Buffer(Buffer const & buffer) :
	IsAllocated(false)
{
	BufferPtr = buffer.BufferPtr;
	Size = buffer.Size;
}


/***********************************************************************************************
 * Buffer::operator = -- Assignment operator for the buffer object.                            *
 *                                                                                             *
 *    This will make a duplicate of the buffer object specified. Any buffer pointed to by the  *
 *    left hand buffer will be lost (possibley freed as a result).                             *
 *                                                                                             *
 * INPUT:   buffer   -- Reference to the right hand buffer object.                             *
 *                                                                                             *
 * OUTPUT:  Returns with a reference to the copied buffer object.                              *
 *                                                                                             *
 * WARNINGS:   none                                                                            *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   08/02/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
Buffer & Buffer::operator = (Buffer const & buffer)
{
	if (&buffer != this) {
		if (IsAllocated) {
			delete [] BufferPtr;
		}
		IsAllocated = false;
		BufferPtr = buffer.BufferPtr;
		Size = buffer.Size;
	}
	return(*this);
}


/***********************************************************************************************
 * Buffer::~Buffer -- Destructor for buffer object.                                            *
 *                                                                                             *
 *    This destructor will free any buffer it is responsible for.                              *
 *                                                                                             *
 * INPUT:   none                                                                               *
 *                                                                                             *
 * OUTPUT:  none                                                                               *
 *                                                                                             *
 * WARNINGS:   none                                                                            *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   07/29/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
Buffer::~Buffer(void)
{
	Reset();
}


/***********************************************************************************************
 * Buffer::Reset -- Clears the buffer object to null state.                                    *
 *                                                                                             *
 *    This routine will bring the buffer object into a null (newly constructed) state. If      *
 *    there was any buffer allocated or referred to by this object, it will be freed or        *
 *    dereferenced as necessary.                                                               *
 *                                                                                             *
 * INPUT:   none                                                                               *
 *                                                                                             *
 * OUTPUT:  none                                                                               *
 *                                                                                             *
 * WARNINGS:   This routine will free the buffer if it is responsible for doing so when        *
 *             it is no longer referenced.                                                     *
 *                                                                                             *
 * HISTORY:                                                                                    *
 *   09/07/1996 JLB : Created.                                                                 *
 *=============================================================================================*/
void Buffer::Reset(void)
{
	if (IsAllocated) {
		delete [] BufferPtr;
	}
	BufferPtr = NULL;
	Size = 0;
	IsAllocated = false;
}
