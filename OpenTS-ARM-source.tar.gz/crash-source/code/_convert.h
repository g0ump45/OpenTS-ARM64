/*******************************************************************************
 *                                O P E N  T S
 *******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2025 Electronic Arts Inc.
 * Copyright 2026 OpenTS contributors
 *
 * Contains material derived from Electronic Arts source code.
 * Modified by OpenTS contributors, 2026.
 * EA's GPLv3 Section 7 additional terms and supplemental warranty
 * disclaimers apply; see LICENSE.md.
 ******************************************************************************/

/***********************************************************************************************
 ***              C O N F I D E N T I A L  ---  W E S T W O O D  S T U D I O S               ***
 ***********************************************************************************************
 *                                                                                             *
 *                 Project Name : Command & Conquer                                            *
 *                                                                                             *
 *                     $Archive:: /Commando/Library/_Convert.h                                $*
 *                                                                                             *
 *                      $Author:: Greg_h                                                      $*
 *                                                                                             *
 *                     $Modtime:: 7/22/97 11:37a                                              $*
 *                                                                                             *
 *                    $Revision:: 1                                                           $*
 *                                                                                             *
 *---------------------------------------------------------------------------------------------*
 * Functions:                                                                                  *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

#pragma once

class ConvertClass;
class LightConvertClass;

class LightConvertClass;
template<class T> class DynamicVectorClass;

extern DynamicVectorClass<LightConvertClass *> TileDrawers;

extern ConvertClass * CameoDrawer;
extern ConvertClass * VoxelDrawer;
extern ConvertClass * TerrainDrawer;
extern ConvertClass * TiberiumDrawer;
extern ConvertClass * AnimDrawer;
extern ConvertClass * NormalDrawer;
extern ConvertClass * MouseDrawer;
extern ConvertClass * SidebarDrawer;
extern ConvertClass * IsometricDrawer;
