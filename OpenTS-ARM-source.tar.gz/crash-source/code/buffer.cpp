/*******************************************************************************
 *                                O P E N  T S
 *******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2025 Electronic Arts Inc.
 * Copyright 2026 OpenTS contributors
 *
 * Contains material derived from Electronic Arts source code.
 * Modified by OpenTS contributors, 2026.
 * EA's GPLv3 Section 7 additional terms and supplemental warranty
 * disclaimers apply; see LICENSE.md.
 ******************************************************************************/

/***************************************************************************
 **   C O N F I D E N T I A L --- W E S T W O O D   A S S O C I A T E S   **
 ***************************************************************************
 *                                                                         *
 *                 Project Name : Westwood 32 Bit Library                  *
 *                                                                         *
 *                    File Name : BUFFER.CPP                               *
 *                                                                         *
 *                   Programmer : Phil W. Gorrow                           *
 *                                                                         *
 *                   Start Date : May 18, 1994                             *
 *                                                                         *
 *                  Last Update : June 1, 1994   [PWG]                     *
 *                                                                         *
 *-------------------------------------------------------------------------*
 * Functions:                                                              *
 *   BC::BufferClass -- The default (void) constructor for a buffer class  *
 *   BC::~BufferClass -- The destructor for the buffer class               *
 *   BC::BufferClass -- The standard constructor for a buffer class        *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

#include "always.h"

#include "buffer.h"


/*=========================================================================*/
/* The following PRIVATE functions are in this file:                       */
/*=========================================================================*/


/*= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =*/

/***************************************************************************
 * BC::BufferClass -- The standard constructor for a buffer class          *
 *                                                                         *
 * INPUT:      VOID *   buffer to which should be included in buffer class *
 *               LONG      size of the buffer which we included            *
 *                                                                         *
 * OUTPUT:     NONE                                                        *
 *                                                                         *
 * WARNINGS:   If the buffer passed to this function is equal to NULL,     *
 *               the buffer will be allocated using new.                   *
 *                                                                         *
 * HISTORY:                                                                *
 *   06/01/1994 PWG : Created.                                             *
 *=========================================================================*/
BufferClass::BufferClass(void *buffer, int size)
{
	Size			= size;								// find size of physical buffer

	if (buffer) {                                       // if buffer is specified
		Buffer			= (unsigned char *)buffer;      //    point to it and mark
		Allocated		= false;                        //    it as user allocated
	} else {
		Buffer			= new unsigned char[Size];  // otherwise allocate it and
		Allocated		= true;                     //    mark it system alloced
	}
}

/***************************************************************************
 * BC::BufferClass -- constructor for BufferClass with size only           *
 *                                                                         *
 * INPUT:      LONG the size of the buffer that needs to be allocated      *
 *                                                                         *
 * OUTPUT:     none                                                        *
 *                                                                         *
 * HISTORY:                                                                *
 *   06/01/1994 PWG : Created.                                             *
 *=========================================================================*/
BufferClass::BufferClass(int size)
{
	Size				= size;
	Buffer			= new unsigned char[Size];  // otherwise allocate it and
	Allocated		= true;                     //    mark it system alloced
}

/***************************************************************************
 * BC::BufferClass -- The default (void) constructor for a buffer class    *
 *                                                                         *
 * INPUT:      none                                                        *
 *                                                                         *
 * OUTPUT:     none                                                        *
 *                                                                         *
 * NOTES:      The primary function of this class is to be called by a     *
 *               derived class which will fill in the values after the     *
 *               fact.                                                     *
 *                                                                         *
 * HISTORY:                                                                *
 *   06/01/1994 PWG : Created.                                             *
 *=========================================================================*/
BufferClass::BufferClass(void)
{
	Buffer		= 0;
	Size			= 0;
	Allocated	= false;
}

/***************************************************************************
 * BC::~BUFFERCLASS -- The destructor for the buffer class                 *
 *                                                                         *
 * INPUT:      none                                                        *
 *                                                                         *
 * OUTPUT:     none                                                        *
 *                                                                         *
 * HISTORY:                                                                *
 *   06/01/1994 PWG : Created.                                             *
 *=========================================================================*/
BufferClass::~BufferClass(void)
{
	if (Allocated) {
		delete[] Buffer;
	}
}
