#!/bin/bash

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source "$controlfolder/control.txt"
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/opentsa"
> "$GAMEDIR/log.txt" && exec > "$GAMEDIR/log.txt" 2>&1
cd "$GAMEDIR"

mkdir -p "$GAMEDIR/data" "$GAMEDIR/conf/user" "$HOME/.config"
bind_directories "$HOME/.config/opentsa" "$GAMEDIR/conf/user"

if [ ! -r "$GAMEDIR/data/TIBSUN.MIX" ]; then
  pm_message "Copy your Tiberian Sun files into ports/opentsa/data. See README.md."
  sleep 10
  pm_finish
  exit 1
fi

$ESUDO chmod a+x "$GAMEDIR/Game"
"$GAMEDIR/Game" "-DATADIR=$GAMEDIR/data" "-USERDIR=$HOME/.config/opentsa"
pm_finish
