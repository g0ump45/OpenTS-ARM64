# OpenTS-A

Experimental native ARM64 handheld port of the OpenTS engine.

## Game data

PortMaster does not include Tiberian Sun files. Copy files from a copy of Tiberian Sun that you own into `ports/opentsa/data/`, with `TIBSUN.MIX` directly in that folder.

## Controls

Configure buttons and cursor speed in the in-game **Controls** menu. The default mapping uses the D-pad and left stick for the cursor, A to select, B to cancel/right-click, and Select for the on-screen groups/base controls.

## Notes

This ARM64 build requires glibc 2.34 or newer. It uses the firmware-provided SDL2 library.

Thanks to the OpenTS and OpenTS-A contributors for the engine and handheld work, and to the original Westwood team for Tiberian Sun.
